package com.test.HW5_173050069;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.aditya.filebrowser.Constants;
import com.aditya.filebrowser.FileChooser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import umich.cse.yctung.androidlibsvm.LibSVM;

/*
output labels filename - LABELS.csv
final output filename - FINAL_OUTPUT.csv
 */

public class PredictFragment extends Fragment {

    ProgressDialog progressDialog;
    public static int PICK_TESTFILE = 3000;
    public static int PICK_MODELFILE = 3001;
    Button predictButton;
    Button testFilePicker;
    public String FINAL_OUTPUT = "FINAL_OUTPUT.csv";
    public String LABELS = "LABELS.csv";
    public String outputModel = "outputModel";
    String dataFilePath1;
    TextView final_result, time_taken;

    int tp=0,tn=0,fp=0,fn=0;
    double precision, recall, fscore, accuracy;

    long startTime, endTime, totalTime;
    double secondsTime;

    public PredictFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.predict_fragment, container, false);
        progressDialog = new ProgressDialog(getContext());
        testFilePicker = (Button) view.findViewById(R.id.testfilepicker);
        predictButton = (Button) view.findViewById(R.id.predict_btn);
        final_result = (TextView)view.findViewById(R.id.final_result);
        time_taken = (TextView)view.findViewById(R.id.time_taken);
        testFilePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(getContext(), FileChooser.class);
                i2.putExtra(Constants.SELECTION_MODE, Constants.SELECTION_MODES.SINGLE_SELECTION.ordinal());
                startActivityForResult(i2, PICK_TESTFILE);
            }
        });

        predictButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<String> commands = new ArrayList<>();
                String dataFilePath = testFilePicker.getText().toString();
                dataFilePath1 = dataFilePath;
                Log.d("Test File Path : ",dataFilePath1);
                String modelPath1 = dataFilePath1.substring(0,dataFilePath1.lastIndexOf(File.separator));
                String modelPath = modelPath1 + "/"+outputModel;
                Log.d("Test Model Path : ",modelPath);
//                String outputFilePath = modelPath1 + "/"+LABELS;//outputFileNameInput.getText().toString();
                if(dataFilePath.toLowerCase().contains(".csv")){
                    dataFilePath = convertToLibSVM(dataFilePath);
                }
                commands.add(dataFilePath);
//                commands.add(modelFilePicker.getText().toString());
                commands.add(modelPath);

                commands.add(MainActivity.appFolderPath+LABELS);//outputFileNameInput.getText().toString());
                new AsyncPredictTask().execute(commands.toArray(new String[0]));
                Toast.makeText(getContext(), MainActivity.appFolderPath+LABELS,Toast.LENGTH_LONG).show();
//                createFinalOutputFile(dataFilePath1);
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_TESTFILE && data != null) {
            if (resultCode == Activity.RESULT_OK) {
                Uri file = data.getData();
                testFilePicker.setText(file.getPath());
            }
        }
        if (requestCode == PICK_MODELFILE && data != null) {
            if (resultCode == Activity.RESULT_OK) {
                Uri file = data.getData();
//                modelFilePicker.setText(file.getPath());
            }

        }
    }

    private class AsyncPredictTask extends AsyncTask<String, Void, Void>
    {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setTitle("SVM Predict");
            progressDialog.setMessage("Executing svm-predict, please wait...");
            progressDialog.show();
            Log.d(MainActivity.TAG, "==================\nStart of SVM PREDICT\n==================");
            startTime = System.nanoTime();
        }

        @Override
        protected Void doInBackground(String... params) {
            LibSVM.getInstance().predict(TextUtils.join(" ", params));
            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            endTime = System.nanoTime();
            totalTime = endTime - startTime;
            secondsTime = totalTime/1000000000.0;
            time_taken.setText("Total test time taken in seconds = "+secondsTime);
            progressDialog.dismiss();
            Toast.makeText(getContext(), "SVM Predict has executed successfully!", Toast.LENGTH_LONG).show();
            Log.d(MainActivity.TAG, "==================\nEnd of SVM PREDICT\n==================");
            HelperClass.readLogcat(getContext(), "SVM-Predict Results");
            createFinalOutputFile(dataFilePath1);
        }
    }

    //attach the final prediction with the given test file and save it as the final output file
    private void createFinalOutputFile(String dataFilePath){
        String opPath = dataFilePath.substring(0,dataFilePath.lastIndexOf(File.separator));
        String newOpPath = opPath+"/"+FINAL_OUTPUT;
        Log.d("opPath : ",newOpPath);
        String labelPath = opPath+"/"+LABELS;
        Log.d("LABEL: ",labelPath);
        File opFile = new File(labelPath);
        File testFile = new File(dataFilePath);
        File newOpFile = new File(newOpPath);
        try{
            BufferedReader br_op = new BufferedReader(new FileReader(opFile));
            BufferedReader br_test = new BufferedReader(new FileReader(testFile));
            FileWriter writer = new FileWriter(newOpFile);
            String line_test = br_test.readLine();
            writer.append(line_test+"\n");
            line_test = br_test.readLine();
            writer.append(line_test+"\n");
            line_test = br_test.readLine();
            String line_op = br_op.readLine();
            int count = 0;
            while(line_test!=null){
                int n = line_test.length();
                String[] words = line_test.split(",");
                Log.d("OUTPUT TEST: ",words[6] + ":" + line_op);
                if(line_op.equals("1")){
                    writer.append(line_test+","+"walking\n");
                    if(words[6].toLowerCase().equals("walking")){
                        tp = tp+1;
                    }
                    else{
                        fp = fp+1;
                    }
                    line_op = br_op.readLine();
                    line_test = br_test.readLine();
                }
                else{
                    writer.append(line_test+","+"stationary\n");
                    if(words[6].toLowerCase().equals("stationary")){
                        tn = tn+1;
                    }
                    else{
                        fn = fn+1;
                    }
                    line_op = br_op.readLine();
                    line_test = br_test.readLine();
                }
                count++;

            }
            Log.d("Count Value : ",Integer.toString(count));
            writer.flush();
            writer.close();
            precision = (double)tp/(tp+fp);
            recall = (double)tp/(tp+fn);
            accuracy = (double)(tp+tn)/(tp+tn+fp+fn);
            fscore = (double)(2*tp)/((2*tp)+fp+fn);
            final_result.setText("True Positive = "+tp+", True Negative = "+tn+", False Positive = "+fp+", False Negative = "+fn+"\nPrecision = "+precision +
                    ", Recall = "+recall+"\nAccuracy = "+accuracy + "\nF-score = " + fscore);

        } catch(Exception e){
            e.printStackTrace();
        }
    }

    //convert csv file to libsvm file format
    private String convertToLibSVM(String dataFilePath) {
        String csvFilePath = dataFilePath;
        String filePath = csvFilePath.substring(0, csvFilePath.lastIndexOf(File.separator));
        File file = new File(csvFilePath);
        String csvFile = file.getName();
        int index = csvFile.indexOf(".");
        String newFileName = csvFile.substring(0, index);
        File myFile = new File(filePath,newFileName);
        PrintWriter out = null;
        BufferedReader br = null;
        String line = "";
        String csvSplitBy = ",";
        try {
            FileWriter writer = new FileWriter(myFile);
            br = new BufferedReader(new FileReader(file));
            line = br.readLine();
            line = br.readLine();
            line = br.readLine();
            while (line != null) {
                String[] row = line.split(csvSplitBy);
                //Walking = +1 and Stationary = -1
                try {
                    if (row[6].toLowerCase().equals("walking") || row[6].equals("accident")) {
                        writer.append("+1 1:" + row[3] + " 2:" + row[4] + " 3:" + row[5] + "\n");
                    } else {
                        writer.append("-1 1:" + row[3] + " 2:" + row[4] + " 3:" + row[5] + "\n");
                    }
                    line = br.readLine();
                } catch (Exception e){
                    line = br.readLine();
                }
            }
            writer.flush();
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        String resultPath = filePath+"/"+newFileName;
        return resultPath;
    }

}
