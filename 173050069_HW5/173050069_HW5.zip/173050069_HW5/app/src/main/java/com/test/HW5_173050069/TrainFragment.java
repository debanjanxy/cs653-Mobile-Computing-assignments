package com.test.HW5_173050069;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.aditya.filebrowser.Constants;
import com.aditya.filebrowser.FileChooser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import umich.cse.yctung.androidlibsvm.LibSVM;

/*
Output model file name - outputModel
Kernel used - Radial Basis Function
 */

public class TrainFragment extends Fragment {

    ProgressDialog progressDialog;
    public static int PICK_DATAFILE = 2000;
    Button trainButton;
    Button dataFilePicker;
    public String FINAL_OUTPUT = "FINAL_OUTPUT.csv";
    public String LABELS = "LABELS.csv";
    public String outputModel = "outputModel";
    TextView train_result;
    long startTime, endTime, totalTime;
    double secondsTime;

    int count=0;


    public TrainFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.train_fragment, container, false);
        progressDialog = new ProgressDialog(getContext());
        trainButton = (Button) view.findViewById(R.id.train_btn);
        dataFilePicker = (Button) view.findViewById(R.id.datafilepicker);
        train_result = (TextView)view.findViewById(R.id.train_result);


        trainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String outputModelPath = MainActivity.appFolderPath + outputModel;//outputFileInput.getText().toString();
                String commandString = "-t 2";//commandInput.getText().toString();
                String dataFilePath = dataFilePicker.getText().toString();
                Log.d("Original Path : ",dataFilePath);
                if(dataFilePath.toLowerCase().contains(".csv")){
                    dataFilePath = convertToLibSVM(dataFilePath); //call to the libsvm format
                }
                Log.d("Path:", dataFilePath);
                startTime = System.nanoTime();
                new AsyncTrainTask().execute(new String[]{commandString, dataFilePath, outputModelPath});
            }
        });
        dataFilePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(getContext(), FileChooser.class);
                i2.putExtra(Constants.SELECTION_MODE, Constants.SELECTION_MODES.SINGLE_SELECTION.ordinal());
                startActivityForResult(i2, PICK_DATAFILE);
            }
        });
        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_DATAFILE && data != null) {
            if (resultCode == Activity.RESULT_OK) {
                Uri file = data.getData();
                dataFilePicker.setText(file.getPath());
            }
        }
    }

    private class AsyncTrainTask extends AsyncTask<String, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progressDialog.setTitle("SVM Train");
            progressDialog.setMessage("Executing svm-train, please wait...");
            progressDialog.show();
            Log.d(MainActivity.TAG, "==================\nStart of SVM TRAIN\n==================");
            count = 0;
            startTime = System.nanoTime();
        }

        @Override
        protected Void doInBackground(String... params) {
            LibSVM.getInstance().train(TextUtils.join(" ", params));
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            endTime = System.nanoTime();
            totalTime = endTime - startTime;
            secondsTime = totalTime/1000000000.0;
            train_result.setText("Time taken in nanoseconds = " + totalTime
                            + "\nTme taken in seconds = " + secondsTime);
            progressDialog.dismiss();
            Toast.makeText(getContext(), "SVM Train has executed successfully!", Toast.LENGTH_LONG).show();
            Log.d(MainActivity.TAG, "==================\nEnd of SVM TRAIN\n==================");
            HelperClass.readLogcat(getContext(), "SVM-Train Results");
        }
    }

    //convert csv file to libsvm file format
    private String convertToLibSVM(String dataFilePath) {
        String csvFilePath = dataFilePath;
        String filePath = csvFilePath.substring(0, csvFilePath.lastIndexOf(File.separator)); //the file path upto last folder
        File file = new File(csvFilePath); // create a new file in the previously defined path
        String csvFile = file.getName();
        int index = csvFile.indexOf(".");
        String newFileName = csvFile.substring(0, index); // newFileName has only filename without extension
        File myFile = new File(filePath,newFileName); // create the newFileName file
        BufferedReader br = null;
        String line = "";
        String csvSplitBy = ",";
        try {
            FileWriter writer = new FileWriter(myFile);
            br = new BufferedReader(new FileReader(file));
            line = br.readLine();
            line = br.readLine();
            line = br.readLine();
            while (line != null) {
                Log.d("Train First Line: ",line);
                String[] row = line.split(csvSplitBy);
                //Walking = +1 and Stationary = -1
                try {
                    if (row[6].toLowerCase().equals("walking")) {
                        writer.append("+1 1:" + row[3] + " 2:" + row[4] + " 3:" + row[5] + "\n");
                    } else {
                        writer.append("-1 1:" + row[3] + " 2:" + row[4] + " 3:" + row[5] + "\n");
                    }
                    count = count+1;
                    line = br.readLine();
                } catch (Exception e){
                    line = br.readLine();
                }
            }
            writer.flush();
            writer.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        String resultPath = filePath+"/"+newFileName;
        return resultPath;
    }
}


